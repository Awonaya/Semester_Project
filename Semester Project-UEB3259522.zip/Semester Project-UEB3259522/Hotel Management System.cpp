#include <iostream>
using namespace std;

int main() 
{
	string password;
	string Default="2255";
	int quant;
	int choice;
	string fname, sname, ptelephone;
	//Quantity
	int Qrooms=0, Qpizza=0, Qburger=0, Qnoodles=0, Qcake=0, Qchicken=0;
	//Total items sold
	int Srooms=0, Spizza=0, Sburger=0, Snoodles=0, Scake=0, Schicken=0;
	//Total proce of items
	int Total_rooms=0, Total_pizza=0, Total_burger=0, Total_noodles=0, Total_cake=0, Total_chicken=0;
	
	cout<<"\n\t\t RECEPTION.";
	cout<<"\n\t Quantity of foods and available rooms ";
	cout<<"\n Rooms Available:";
	cin>>Qrooms;
	cout<<"\n Quantity of Pizza:";
	cin>>Qpizza;
	cout<<"\n Quantity of Burger:";
	cin>>Qburger;
	cout<<"\n Quantity of Noodles:";
	cin>>Qnoodles;
	cout<<"\n Quantity of cake:";
	cin>>Qcake;
	cout<<"\n Quantity of chicken-roll:";
	cin>>Qchicken;
	
	cout<<"\n\t Costumers Details";
	cout<<"\n Enter your First name:";
	cin>>fname;
	cout<<"\n Enter your Surname:";
	cin>>sname;
	cout<<"\n Enter your telephone number:";
	cin>>ptelephone;
	
	m:
	cout<<"\n\t\t CUSTOMERS SERVICE.";
	cout<<"\n\t\t\t Please select from the menu options ";
	cout<<"\n\n1) Rooms ";
	cout<<"\n2) Pizza ";
	cout<<"\n3) Burger ";
	cout<<"\n4) Noodles";
	cout<<"\n5) Cake";
	cout<<"\n6) Chicken-roll ";
	cout<<"\n7) Information regarding sales and collections";
	cout<<"\n8) Exit";
	
	cout<<"\n\n Please Enter your choice:";
	cin>>choice;
	
	switch(choice)
	{
		case 1:
			cout<<"\n\n Enter the number of rooms you want: ";
			
			cin>>quant;
			if(Qrooms-Srooms >=quant)
			{
				Srooms=Srooms+quant;
				Total_rooms= Total_rooms+quant*1200;
				cout<<"\n\n\t\t"<<quant<<"room/rooms have been alloted to you!";
			}
			else
			{
				cout<<"\n\tOnly" <<Qrooms-Srooms<<"Rooms are remaining in hotel ";
				break;
			}
			break;
			
			case 2:
				cout<<"\n\n Enter Pizza Quantity :";
				
				cin>>quant;
				if(Qpizza-Spizza >=quant)
				{
					Spizza=Spizza+quant;
					Total_pizza= Total_pizza+quant*250;
					cout<<"\n\n\t\t"<<quant<<" Pizza is the order! ";
				}
				else
				cout<<"\n\tOnly"<<Qpizza-Spizza<<"Pizza remaining in the hotel ";
				break;
			
				case 3:
					cout<<"\n\n Enter Burger quantity :";
					
					cin>>quant;
					if(Qburger-Sburger >=quant)
					{
						Sburger=Sburger+quant;
						Total_burger= Total_burger+quant*120;
						cout<<"\n\n\t\t"<<quant<<" Burger is the order! ";
					}
					else
					cout<<"\n\tOnly"<<Qburger-Sburger<<"Burgers remaining in the hotel ";
					break;
					
					case 4:
						cout<<"\n\n Enter Noodles Quantity :";
						
						cin>>quant;
						if(Qnoodles-Snoodles >=quant)
						{
							Snoodles=Snoodles+quant;
							Total_noodles= Total_noodles+quant*140;
							cout<<"\n\n\t\t"<<quant<<" Noodle is the order!";
						}
						else 
						cout<<"\n\tOnly"<<Qnoodles-Snoodles<<"Noodles remaining in hotel ";
						break;
						
							case 5:
						cout<<"\n\n Enter Cake Quantity :";
						
						cin>>quant;
						if(Qcake-Scake >=quant)
						{
							Scake=Scake+quant;
							Total_cake= Total_cake+quant*120;
							cout<<"\n\n\t\t"<<quant<<" Cake is the order!";
						}
						else 
						cout<<"\n\tOnly"<<Qcake-Scake<<"Cake remaining in hotel ";
						break;
						
							case 6:
						cout<<"\n\n Enter Chicken-roll Quantity :";
						cin>>quant;
						if(Qchicken-Schicken >=quant){
						
							cout<<"\n\n\t\t"<<quant<<" Chicken-roll is the order!";
						}
						else 
						cout<<"\n\tOnly"<<Qnoodles-Snoodles<<"Chicken-roll remaining in hotel ";
						break;
						
						case 7:
							cout<<"\n\n Enter Managers Password:";
							cin>>password;
							if(password==Default)
							{
								cout<<"\n\t\tDetails of sales and collection";
							cout<<"\n\n Number of rooms we had :"<<Qrooms;
							cout<<"\n\n Number of rooms we have gave for rent "<<Srooms;
							cout<<"\n\n Remaining rooms "<<Qrooms-Srooms;
							cout<<"\n\n Total rooms collection for the day : "<<Total_rooms;
							
							cout<<"\n\n Number of Pizza we had :"<<Qpizza;
							cout<<"\n\n Number of Pizza we sold :"<<Spizza;
							cout<<"\n\n Remaining remaining Pizza : "<<Qpizza-Spizza;
							cout<<"\n\n Total Pizza collection for the day : "<<Total_pizza;
							
							cout<<"\n\n Number of Burger we had :"<<Qburger;
							cout<<"\n\n Number of Burger we sold : "<<Sburger;
							cout<<"\n\n Remaining Burger :"<<Qburger-Sburger;
							cout<<"\n\n Total Burger collection for the day : "<<Total_burger;
							
							cout<<"\n\n Number of Noodles we had :"<<Qnoodles;
							cout<<"\n\n Number of Noodles we sold :"<<Snoodles;
							cout<<"\n\n Remaining Noodles :"<<Qnoodles-Snoodles;
							cout<<"\n\n Total Noodles collection for the day : "<<Total_noodles;
							
							cout<<"\n\n Number of Cakes we had :"<<Qcake;
							cout<<"\n\n Number of Cakes we sold :"<<Scake;
							cout<<"\n\n Remaining Cakes :"<<Qcake-Scake;
							cout<<"\n\n Total Cakes collection for the day : "<<Total_cake;
							
							cout<<"\n\n Number of Chicken-roll we had :"<<Qchicken;
							cout<<"\n\n Number of Chicken-roll we sold "<<Schicken;
							cout<<"\n\n Remaining Chicken-roll "<<Qchicken-Schicken;
							cout<<"\n\n Total Chicken-roll collection for the day : "<<Total_chicken;
							
							cout<<"\n\n\n Total Collection for the day: "<<Total_rooms+Total_pizza+Total_burger+Total_noodles+Total_cake+Total_chicken;
							break;
							
							}
							else{
								cout<<"Opps! You have invalid Password enterd!";
								return 0;
								
							}
							
							case 8:
								exit(0);
								
								default:
									cout<<"Opps you have invalid number enterd! Select from the menu options below.";
							
							
							
							
							
	}
	goto m;

			}
			
			

	
	
